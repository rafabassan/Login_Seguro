package com.exemplo.loginseguro.model;

public enum Role {
    ADMIN,
    ORIENTADOR,
    ALUNO
}
