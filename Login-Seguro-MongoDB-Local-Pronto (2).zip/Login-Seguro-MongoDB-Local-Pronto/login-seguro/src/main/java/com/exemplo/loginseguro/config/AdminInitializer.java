package com.exemplo.loginseguro.config;

import com.exemplo.loginseguro.model.Role;
import com.exemplo.loginseguro.model.Usuario;
import com.exemplo.loginseguro.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AdminInitializer {

    @Bean
    CommandLineRunner criarAdministrador(
            UsuarioRepository repository,
            PasswordEncoder encoder) {

        return args -> {
            String email = "admin@local.com";

            if (repository.findByEmailIgnoreCase(email).isEmpty()) {
                Usuario admin = new Usuario(
                        "Administrador",
                        email,
                        encoder.encode("Admin@123"),
                        Role.ADMIN
                );
                admin.setAtivo(true);
                repository.save(admin);
            }
        };
    }
}
