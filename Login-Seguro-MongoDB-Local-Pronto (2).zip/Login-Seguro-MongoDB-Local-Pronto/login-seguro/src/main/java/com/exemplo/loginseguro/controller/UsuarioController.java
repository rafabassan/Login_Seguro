
package com.exemplo.loginseguro.controller;

import com.exemplo.loginseguro.model.Role;
import com.exemplo.loginseguro.service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/usuarios")
    public String usuarios(Model model) {
        model.addAttribute("usuarios", usuarioService.listar());
        model.addAttribute("roles", Role.values());
        return "admin/usuarios";
    }

    @PostMapping("/usuarios/{id}/role")
    public String alterarRole(
            @PathVariable Long id,
            @RequestParam Role role) {
        usuarioService.atualizarRole(id, role);
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/{id}/status")
    public String alterarStatus(@PathVariable Long id) {
        usuarioService.alterarStatus(id);
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/{id}/excluir")
    public String excluir(@PathVariable Long id) {
        usuarioService.excluir(id);
        return "redirect:/admin/usuarios";
    }
}