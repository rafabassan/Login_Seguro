
package com.exemplo.loginseguro.service;

import com.exemplo.loginseguro.model.Role;
import com.exemplo.loginseguro.model.Usuario;
import com.exemplo.loginseguro.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(
            UsuarioRepository repository,
            PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    public Usuario cadastrar(Usuario usuario) {
        usuario.setEmail(
                usuario.getEmail().trim().toLowerCase(Locale.ROOT));

        if (repository.existsByEmailIgnoreCase(usuario.getEmail())) {
            throw new IllegalArgumentException(
                    "Já existe um usuário com este e-mail.");
        }

        usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        usuario.setRole(Role.ALUNO);
        usuario.setAtivo(true);

        return repository.save(usuario);
    }

    public List<Usuario> listar() {
        return repository.findAll();
    }

    public Usuario buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Usuário não encontrado."));
    }

    public void atualizarRole(Long id, Role role) {
        Usuario usuario = buscar(id);
        usuario.setRole(role);
        repository.save(usuario);
    }

    public void alterarStatus(Long id) {
        Usuario usuario = buscar(id);
        usuario.setAtivo(!usuario.isAtivo());
        repository.save(usuario);
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }
}