# Checklist de Entrega

- [x] Cadastro de usuários
- [x] Login
- [x] Logout
- [x] BCrypt
- [x] Spring Security
- [x] Três perfis
- [x] Controle de rotas
- [x] MongoDB Atlas
- [x] Sessões em MongoDB
- [x] Thymeleaf
- [x] Separação entre apresentação e lógica
- [x] Estrutura preparada para temas
- [x] README
- [x] .env.example
- [x] Gitflow documentado
- [x] Documentação acadêmica em PDF

Antes da publicação, configure as credenciais reais do MongoDB somente como variáveis de ambiente.
