# Login Seguro

Sistema individual de login seguro desenvolvido com Java Spring Boot, Thymeleaf, Spring Security e MongoDB.

## Tecnologias

- Java 21
- Spring Boot 3.5.6
- Spring Security
- Thymeleaf
- MongoDB
- Spring Session MongoDB
- Maven

## MongoDB local

Este projeto foi configurado para usar MongoDB local. Nao e necessario MongoDB Atlas.

URI utilizada:

`mongodb://localhost:27017`

Banco utilizado:

`login_seguro`

### Antes de executar

1. Instale e inicie o MongoDB Server.
2. Abra o MongoDB Compass, se quiser acompanhar os dados.
3. No Compass, use:

`mongodb://localhost:27017`

O banco `login_seguro` e as colecoes serao criados automaticamente quando a aplicacao gravar os primeiros dados.

## Como executar

Abra o terminal na pasta do projeto e execute:

```bash
mvn spring-boot:run
```

Depois acesse:

`http://localhost:8080/login`

## Acesso de administrador para teste

O projeto cria automaticamente um administrador na primeira inicializacao, caso ele ainda nao exista.

- E-mail: `admin@local.com`
- Senha: `Admin@123`

Depois de testar, altere a senha ou remova esse usuario para uso real.

## Cadastro de usuario

Acesse:

`http://localhost:8080/cadastro`

Novos cadastros entram inicialmente como `ALUNO`.

## Perfis

O sistema possui tres perfis:

- `ADMIN`
- `ORIENTADOR`
- `ALUNO`

As permissoes sao controladas pelo Spring Security.

## Rotas principais

- `/login` - login
- `/cadastro` - cadastro
- `/dashboard` - area autenticada
- `/admin/usuarios` - area administrativa
- `/aluno` - area do aluno
- `/orientador` - area do orientador
- `/logout` - logout

## Estrutura

A aplicacao separa responsabilidades entre controllers, services, repository, model, configuracao de seguranca e templates Thymeleaf.

## GitHub

Nao envie senhas, arquivos `.env` ou credenciais reais para o GitHub. O projeto ja possui `.gitignore` para arquivos locais sensiveis.
